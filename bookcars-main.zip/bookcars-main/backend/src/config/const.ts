const Const = {
  PAGINATION_MODE: {
    CLASSIC: 'CLASSIC',
    INFINITE_SCROLL: 'INFINITE_SCROLL',
  },
}

export default Const
