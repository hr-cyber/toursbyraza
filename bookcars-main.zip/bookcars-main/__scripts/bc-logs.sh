#!/usr/bin/env bash

tail -f /opt/bookcars/api/logs/all.log
