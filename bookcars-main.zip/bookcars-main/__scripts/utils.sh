#!/bin/bash

 grep CRON-FREE-MEM /var/log/syslog
